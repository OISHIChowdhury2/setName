var Storage = artifacts.require("./SmartContract")

module.exports = (_deployer,network,accounts) => {
  // Use deployer to state migration tasks.
 
  const getterName = " hello";
  _deployer.deploy(Storage, getterName ,accounts[0]);
};
