import { conn} from "../config/conn";
import { config} from "../config/api";
import Web3 from 'web3';

export class service{
    constructor(provider){
        this.web3 =new Web3(provider);
        this.config = new this.web3.eth.Contract(
            config.contractABI,
            config.contractAddress
        );
    }
   async getName(){
    const Newname =await this.config.methods.name.call();
    return Newname;   
   }
async getAddres(){
    const newAddres =await this.config.methods.addres.call();
    return newAddres;
   }

async getPhone(){
    const newPhone =await this.config.methods.phone.call();
    return newPhone;
    }
}

