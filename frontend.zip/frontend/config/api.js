export const api={
   contractAddress : "0xCA4615BF2E9D16D57F92D1A3A12c5C6181340320",
   "abi": [
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "newName",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "newAddres",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "newPhone",
          "type": "uint256"
        }
      ],
      "name": "setName",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "getName",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    }
  ],

}