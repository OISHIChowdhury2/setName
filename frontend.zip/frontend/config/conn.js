export const ethConfig = {
    provider: "http://127.0.0.1:7545"
}