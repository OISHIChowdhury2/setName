

import React, { useEffect, useState } from "react";

import{config} from "../../config/api";
import {service} from "../../Service/service";

function Index(props) {
    const [conName , setConName]= useState("");

    let setservice =new service(window.ethereum);

    useEffect(() =>{
        async function fetchDate(){
            const name =await setservice.getName();
            setConName(name);
            const addres =await setservice.getName();
            setConName(addres);
            const phone =await setservice.getName();
            setConName(phone);
        }
        fetchDate();
    },[]);


  return (
    <>
    
    <div class="container">
  <div class="row">
    <div class="col">
    <form>
    <h1 >Enter Your Information</h1>
        <div class="mb-3">
          <label  class="form-label">Name</label>
          <input type="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
        </div>
        <div class="mb-3">
          <label  class="form-label">Address</label>
          <input class="form-control" id="exampleInputPassword1"/>
        </div>
        <div class="mb-3">
          <label  class="form-label">Phone</label>
          <input class="form-control" id="exampleInputPassword1"/>
        </div>
        <div class="mb-3 form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
   </div>
   </div>
   </div>
    </>
  );
};
export default Index;