import './App.css';

import React from "react";
import Index from './SmartContract/Index';


function App() {
  return (
    <>
      <Index />
  
    </>
  );
}
export default App;